package com.delegate;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class AppDelegate {
	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
		
	}
	@Autowired
	private RestTemplate restTemp;
	
	public String loadUsers() {
		
		String response = restTemp.exchange("http://localhost:8080/mainapp/loadusers", HttpMethod.GET,
				null, 
				new ParameterizedTypeReference<String>()
				{}).getBody();
		
		return response + "" + new Date();
	}
	
	public String loadDept() {
		
		String response = restTemp.exchange("http://localhost:8070/deptapp/loaddepts/boaindia", HttpMethod.GET,
				null, 
				new ParameterizedTypeReference<String>()
				{}).getBody();
		
		return response + "" + new Date();
	}
	

}
