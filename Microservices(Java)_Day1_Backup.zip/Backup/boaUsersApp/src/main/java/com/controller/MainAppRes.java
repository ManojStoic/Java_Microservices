 package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.service.UserService;

@RestController
@RequestMapping("/mainapp")
public class MainAppRes {
	
	@Autowired
	private UserService service;
	
	@PostMapping("/login")
	 
	public String loginValid(@RequestParam("uname")String name,@RequestParam("pass")String pass) {
		if(service.loginValidated(name, pass)) {
			return "user success";
			
		}
		return "user failed";
	}

}
