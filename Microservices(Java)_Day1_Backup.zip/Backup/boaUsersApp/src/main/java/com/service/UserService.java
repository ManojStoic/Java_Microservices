package com.service;

import org.springframework.stereotype.Service;

@Service
public class UserService {
	
	
	
	public boolean loginValidated(String name,String pass) {
		if(name.equals("admin") && pass.equals("manager")) {
			return true;
		}
		return false;
	}

}